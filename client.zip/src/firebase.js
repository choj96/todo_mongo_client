import "firebase/compat/auth";
import firebase from "firebase/compat/app";
// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyBwzN3HhEg8vXHDJVbS99js_UWebOZ7Q20",
  authDomain: "todo-mongo-41acd.firebaseapp.com",
  projectId: "todo-mongo-41acd",
  storageBucket: "todo-mongo-41acd.appspot.com",
  messagingSenderId: "100362567010",
  appId: "1:100362567010:web:84edd1a9db0f2e87edc03b",
};

// Initialize Firebase
firebase.initializeApp(firebaseConfig);
export default firebase;
