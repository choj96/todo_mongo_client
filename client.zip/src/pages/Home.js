import React from "react";

const Home = () => {
  return <div className="p-6 m-4 shadow">Home</div>;
};

export default Home;
