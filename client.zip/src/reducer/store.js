// slice 들을 모아서 store 에 저장
import { configureStore } from "@reduxjs/toolkit";
import userSlice from "./userSlice";
const store = configureStore({
  reducer: {
    user: userSlice.reducer,
  },
});
export default store;
